#!/data/data/com.termux/files/usr/bin/bash
APPDIR="$HOME/buildAPKs/sources/github/BrokenEthicsaLab2025/IncomeGenieStub"
cd "$APPDIR" || exit 1

echo "[•] Compiling Java stub..."
aapt package -f -m -J src -M AndroidManifest.xml -S res -I $PREFIX/share/aapt/android.jar
javac -d obj -classpath $PREFIX/share/aapt/android.jar src/com/brokenethicsalab/incomegenie/MainActivity.java
dx --dex --output=classes.dex obj
aapt package -f -M AndroidManifest.xml -S res -I $PREFIX/share/aapt/android.jar -F resources.ap_
zip -r assets.zip assets
apkbuilder IncomeGenieHardened.apk -u -z resources.zip -f classes.dex

echo "[•] Signing APK..."
keytool -genkey -v -keystore keystore.jks -storepass pass123 -alias geniekey -keypass pass123 -dname "CN=IncomeGenie,O=BrokenEthicsaLab,C=US" -keyalg RSA -keysize 2048 -validity 10000
jarsigner -keystore keystore.jks -storepass pass123 -keypass pass123 IncomeGenieHardened.apk geniekey
zipalign -v 4 IncomeGenieHardened.apk IncomeGenieHardened_signed.apk

echo "[✓] Final APK: $APPDIR/IncomeGenieHardened_signed.apk"
