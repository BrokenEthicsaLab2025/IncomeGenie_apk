#!/data/data/com.termux/files/usr/bin/bash
APPDIR="$HOME/buildAPKs/sources/github/BrokenEthicsaLab2025/IncomeGenieStub"
cd "$APPDIR" || exit 1

echo "[•] Building APK stub with ELF + native launcher..."

aapt package -f -M AndroidManifest.xml -S res -I $PREFIX/share/aapt/android.jar -F resources.ap_
zip -r assets.zip assets
zip IncomeGenieNative.apk resources.ap_ assets.zip

echo "[•] Signing APK with uber-apk-signer..."
mkdir -p signed
wget -q https://github.com/patrickfav/uber-apk-signer/releases/download/v1.2.1/uber-apk-signer-1.2.1.jar -O uber-apk-signer.jar
java -jar uber-apk-signer.jar -a IncomeGenieNative.apk --out signed

echo "[✓] Final APK: $APPDIR/signed/IncomeGenieNative-aligned-signed.apk"
